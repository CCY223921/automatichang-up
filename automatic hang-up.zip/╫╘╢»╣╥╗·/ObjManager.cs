using Games.LogicObj;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjManager : MonoBehaviour
{
    private Obj_MainPlayer m_MainPlayer;                //��ǰ�ͻ�������ɫ
    public Obj_MainPlayer MainPlayer { get { return m_MainPlayer; } }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
